# Frappe Inspector CLI

```bash
frappe-inspector scan .
frappe-inspector scan ./frappe-bench --app erpnext
frappe-inspector explain . --rule FI040
frappe-inspector diff . --base-ref origin/main --format sarif --output frappe-inspector.sarif
frappe-inspector snapshot . --output .frappe-inspector/snapshot.json
frappe-inspector license activate FI-PRO-XXXX-XXXX-XXXX-XXXX-XXXX
frappe-inspector license status
frappe-inspector license refresh
frappe-inspector license deactivate
```

The CLI returns `0` when the configured threshold is clear, `1` when findings reach the threshold, `2` for execution errors and `3` when a requested Universal Pro capability is not licensed.

Use `--app <app-name>` when scanning a complete bench. Frappe Inspector indexes dependencies for resolution, but reports and exit status only include findings from the selected app. References found in test and patch files are retained as review notes rather than active errors.

Security diagnostics follow whitelisted and conventional web entrypoints through local helpers. Markdown, JSON, SARIF and terminal output include the entry, flow and sensitive sink when available. Query filters and projected fields are validated against the effective DocType schema, while recognized optional-app and runtime DocType guards reduce integration noise.

Use `explain` with `--rule`, `--source` and `--line` to isolate one finding and its evidence without losing normal report formatting.

Reports now include concise fix guidance for high-value Frappe rules. Use Markdown or SARIF in CI when you want reviewers to see both the source-to-sink evidence and the recommended remediation.

## Universal Pro review workflow

CLI 1.4.0 adds these commands and options:

```bash
frappe-inspector scan . --new-only --base-ref origin/main
frappe-inspector scan . --policy .frappe-inspector/policy.json
frappe-inspector scan . --suppressions .frappe-inspector/suppressions.json --audit-output suppression-audit.json
frappe-inspector plan . --base-ref origin/main --include-safe --output migration-plan.json
frappe-inspector diff . --base-ref origin/main --format html --output frappe-inspector.html
```

- `--new-only` removes findings whose stable fingerprints are already present at the Git or snapshot baseline. It does not classify changed lines or prove the rest of the repository safe.
- `--policy` accepts version `1` JSON with `minimumSeverity`, `failOn` and per-rule `enabled` or `severity` values.
- `--suppressions` accepts version `1` entries matched by fingerprint or rule and optional path. Every entry requires `id`, `justification`, `author`, `createdAt` and `expiresAt`. `--audit-output` records applied, expired and unused entries.
- `--new-only` uses stable fingerprint multisets and Git rename detection, not changed-line heuristics.
- `plan` emits ordered preflight, backfill, schema and verification phases with non-executed `<site>`/`<patch>` command templates.
- `--format html` writes a self-contained escaped report.
- PR comments are a GitHub Action capability and are not a CLI capability.

These interfaces require Universal Pro.

```bash
frappe-inspector scan ./frappe-bench --app erpnext --format markdown
frappe-inspector explain ./frappe-bench --rule FI042 --source apps/erpnext/api.py --line 42
```

Benchmark proof is reproducible from the monorepo: `npm run check:benchmark` validates the 22-case controlled Frappe-specific corpus, and `node scripts/run-ground-truth-benchmark.mjs --competitor packages/core/test-fixtures/ground-truth/competitors/bandit-semgrep-2026-08-01.json` compares against real Bandit/Semgrep runs. The report separates Frappe Inspector's 3 migration-only expectations from the 17-finding generic competitor subset.

`license activate` stores the subscription key and signed certificate in `~/.frappe-inspector/license.json` with user-only permissions. `FRAPPE_INSPECTOR_LICENSE_KEY` and `--license-file` remain ephemeral and are never persisted. `license deactivate` releases both CLI and MCP access for this device.

Documentation: https://github.com/Belius303/frappe-inspector-support
