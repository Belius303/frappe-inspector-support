# Frappe Inspector MCP Server

The local `stdio` MCP server exposes read-only Frappe project analysis to compatible AI clients.

```json
{
  "mcpServers": {
    "frappe-inspector": {
      "command": "frappe-inspector-mcp",
      "args": [],
      "env": {
        "FRAPPE_INSPECTOR_LICENSE_KEY": "${FRAPPE_INSPECTOR_LICENSE_KEY}"
      }
    }
  }
}
```

Tools include project scan, finding explanation with source-to-sink evidence, pull request and migration plan review, DocType listing, effective schema lookup, field usage search, Git schema comparison and CI report generation. Project files are read as text and never executed.

MCP 1.4.0 adds `review_new_frappe_pull_request`, which filters findings by stable fingerprint against a Git base, and `create_frappe_migration_plan`, which returns read-only ordered migration guidance including safe changes. MCP does not create suppressions, generate HTML or write PR comments. Those responsibilities remain with the CLI/editor or GitHub Action.

The MCP server shares the local device record with the CLI but keeps its product-bound certificate separate. Run `frappe-inspector license deactivate` to release both CLI and MCP access for this device.

Documentation: https://github.com/Belius303/frappe-inspector-support
